package practiceproject;

public class MatrixMultiplication {
	    public static void main(String[] args) {
	        int[][] matrix1 = { { 2, 2, 3 }, { 4, 5, 6 } };
	        int[][] matrix2 = { { 9, 8 }, { 9, 10 }, { 11, 12 } };

	        int r1 = matrix1.length;
	        int col1 = matrix1[0].length;
	        int col2 = matrix2[0].length;

	        int[][] result = multiplyMatrices(matrix1, matrix2, r1, col1, col2);

	        // Displaying the result
	        System.out.println("Resultant Matrix:");
	        for (int i = 0; i < r1; i++) {
	            for (int j = 0; j < col2; j++) {
	                System.out.print(result[i][j] + " ");
	            }
	            System.out.println();
	        }
	    }

	    public static int[][] multiplyMatrices(int[][] matrix1, int[][] matrix2, int rows1, int cols1, int cols2) {
	        int[][] result = new int[rows1][cols2];

	        for (int i = 0; i < rows1; i++) {
	            for (int j = 0; j < cols2; j++) {
	                for (int k = 0; k < cols1; k++) {
	                    result[i][j] += matrix1[i][k] * matrix2[k][j];
	                }
	            }
	        }

	        return result;
	    }
	}


