package practiceproject;

import java.util.*;

public class Question6 {
	
	public static void main(String[] args) {
		
		//HashMap is the collection which store element in form of key-value pair where key should be unique and values can be duplicate.
		HashMap<String,Integer> hashmap = new HashMap<String,Integer>();
		hashmap.put("a", 10); //String is key and Value is Integer.
		hashmap.put("b", 20);
		hashmap.put("c", 10);
		hashmap.put("d", 10);
		
		System.out.println(hashmap);
		
		//Size of HashMap
		System.out.println("Size of hashmap is "+hashmap.size());
		
		//GET the value of particular key
		Integer a=hashmap.get("b");
		System.out.println(a);
		
		
		
	}

}
