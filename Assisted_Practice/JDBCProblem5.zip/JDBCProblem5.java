package practiceproject;
import java.sql.*;

public class JDBCProblem5 {
	
	    public static void main(String[] args) {
	        Connection connection = null;
	        Statement statement = null;

	        try {
	            // Load the JDBC driver
	            Class.forName("<driver-class-name>");

	            // Establish a connection
	            String url = "<database-url>";
	            String username = "<username>";
	            String password = "<password>";
	            connection = DriverManager.getConnection(url, username, password);

	            // Create a statement
	            statement = connection.createStatement();

	            // Insert a new record
	            String insertQuery = "INSERT INTO employees (id, name, age) VALUES (1, 'John', 30)";
	            int rowsInserted = statement.executeUpdate(insertQuery);
	            System.out.println(rowsInserted + " record(s) inserted.");

	            // Update a record
	            String updateQuery = "UPDATE employees SET age = 32 WHERE id = 1";
	            int rowsUpdated = statement.executeUpdate(updateQuery);
	            System.out.println(rowsUpdated + " record(s) updated.");

	            // Delete a record
	            String deleteQuery = "DELETE FROM employees WHERE id = 1";
	            int rowsDeleted = statement.executeUpdate(deleteQuery);
	            System.out.println(rowsDeleted + " record(s) deleted.");

	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the resources
	            try {
	                if (statement != null) {
	                    statement.close();
	                }
	                if (connection != null) {
	                    connection.close();
	                }
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}


