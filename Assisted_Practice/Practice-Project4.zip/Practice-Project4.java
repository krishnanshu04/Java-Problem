package practiceproject;

public class Question4 {
	
	public int num;
	
	//Default Constructor or Unparameterized constructor
	Question4(){
		System.out.println("This is default constructor");
	}
	
	//Parameterized constructor
	Question4(int num){
		this.num=num;
		System.out.println("This is parameterized constructor and the value of num is "+ num);
	}
	
	public static void main(String[] args) {
		
		Question4 obj1 = new Question4(); // This will called default constructor.
		Question4 obj2 = new Question4(10); // This will called parameterized constructor.
		
	}

}
