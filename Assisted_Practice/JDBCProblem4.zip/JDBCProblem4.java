package practiceproject;
import java.sql.*;

public class JDBCProblem4 {
	

	
	    public static void main(String[] args) {
	        Connection connection = null;
	        Statement statement = null;

	        try {
	            // Load the JDBC driver
	            Class.forName("<driver-class-name>");

	            // Establish a connection
	            String url = "<database-url>";
	            String username = "<username>";
	            String password = "<password>";
	            connection = DriverManager.getConnection(url, username, password);

	            // Create a statement
	            statement = connection.createStatement();

	            // Create a new database
	            String createDatabaseQuery = "CREATE DATABASE my_database";
	            statement.executeUpdate(createDatabaseQuery);
	            System.out.println("Database created successfully.");

	            // Select the newly created database
	            String useDatabaseQuery = "USE my_database";
	            statement.executeUpdate(useDatabaseQuery);
	            System.out.println("Selected database: my_database");

	            // Drop the database
	            String dropDatabaseQuery = "DROP DATABASE my_database";
	            statement.executeUpdate(dropDatabaseQuery);
	            System.out.println("Database dropped successfully.");

	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the resources
	            try {
	                if (statement != null) {
	                    statement.close();
	                }
	                if (connection != null) {
	                    connection.close();
	                }
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}



