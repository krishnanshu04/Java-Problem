package practiceproject;
import java.sql.*;

public class JDBCProblem2 {
	
	    public static void main(String[] args) {
	        Connection connection = null;
	        Statement statement = null;
	        ResultSet resultSet = null;

	        try {
	            // Load the JDBC driver
	            Class.forName("<driver-class-name>");

	            // Establish a connection
	            String url = "<database-url>";
	            String username = "<username>";
	            String password = "<password>";
	            connection = DriverManager.getConnection(url, username, password);

	            // Create a statement
	            statement = connection.createStatement();

	            // Execute a query
	            String query = "SELECT * FROM employees";
	            resultSet = statement.executeQuery(query);

	            // Process the result set
	            while (resultSet.next()) {
	                int id = resultSet.getInt("id");
	                String name = resultSet.getString("name");
	                int age = resultSet.getInt("age");

	                System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
	            }

	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the resources
	            try {
	                if (resultSet != null) {
	                    resultSet.close();
	                }
	                if (statement != null) {
	                    statement.close();
	                }
	                if (connection != null) {
	                    connection.close();
	                }
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}
