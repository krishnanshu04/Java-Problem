package practiceproject;

import java.util.LinkedList;

public class SingleLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList<Character> list = new LinkedList<>();
		
		list.add('a');
		list.add('b');
		list.add('c');
		list.add('e');
		list.add('f');
		list.add('d');
		
		System.out.println("Before removing first element from linkedList");
		System.out.println(list);
		
		list.removeFirstOccurrence('a');
		
		System.out.println("After removing first element from linkedList");
		System.out.println(list);

	}

}
