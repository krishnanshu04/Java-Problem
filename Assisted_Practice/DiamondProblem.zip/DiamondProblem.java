package practiceproject;

interface Interface1{
	
	public static final int i1=10;
	void show1();
	
	default void fun1() {
		System.out.println("Default Concrete method inside interface with body");
	}
	
	private void fun2() {
		System.out.println("Private Concrete method inside interface with body");
	}
	
	static void fun3() {
		System.out.println("Static Concrete method inside interface with body");
	}
	
}

interface Interface2{
	public static final int i2=20;
	void show2();
	
}

interface Interface3 extends Interface1,Interface2{
	public static final int i3=30;
	void show3();
}

class MultipleInheritance implements Interface3{
	
	public void show1() {
		System.out.println("Abstract method of interface1");
	}
	
	public void show2() {
		System.out.println("Abstract method of interface2");
	}
	
	public void show3() {
		System.out.println("Abstract method of interface3");
	}
}

public class DiamondProblem {
	
	public static void main(String[] args) {
		
		MultipleInheritance obj=new MultipleInheritance();
		obj.show1();
		obj.show2();
		obj.show3();
	}

}
