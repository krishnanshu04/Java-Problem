package practiceproject;
import java.sql.*;

public class JDBCProblem3 {
	
	    public static void main(String[] args) {
	        Connection connection = null;
	        CallableStatement callableStatement = null;

	        try {
	            // Load the JDBC driver
	            Class.forName("<driver-class-name>");

	            // Establish a connection
	            String url = "<database-url>";
	            String username = "<username>";
	            String password = "<password>";
	            connection = DriverManager.getConnection(url, username, password);

	            // Prepare a callable statement for the stored procedure
	            String procedureCall = "{call my_stored_procedure(?, ?)}";
	            callableStatement = connection.prepareCall(procedureCall);

	            // Set input parameters
	            callableStatement.setString(1, "John");
	            callableStatement.setInt(2, 30);

	            // Execute the stored procedure
	            callableStatement.execute();

	            // Retrieve the output parameter value
	            String message = callableStatement.getString(1);
	            System.out.println("Message from stored procedure: " + message);

	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the resources
	            try {
	                if (callableStatement != null) {
	                    callableStatement.close();
	                }
	                if (connection != null) {
	                    connection.close();
	                }
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}



