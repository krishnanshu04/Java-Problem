package practiceproject;

public class JDBCEnvironment {

}
