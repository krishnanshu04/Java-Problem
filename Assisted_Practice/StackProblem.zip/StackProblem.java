package practiceproject;

import java.util.Stack;

public class StackProblem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stack<Integer> stack = new Stack<>();
		
		//Insert elements to the stack
		stack.push(100);
		stack.push(101);
		stack.push(102);
		stack.push(103);
		stack.push(104);
		stack.push(105);
		
		System.out.print(stack);
		
		//Remove element from the stack by providing index number
		stack.remove(0);
		System.out.print(stack);
		
		//Remove element from stack on the basis of LIFO
		stack.pop();
		System.out.print(stack);
		
		//Element on the top of the stack
		System.out.println(stack.peek());
	}

}
