package practiceproject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LongestSubSquence {
	
	    public static void main(String[] args) {
	        int[] numbers = { 4, 6, 8, 1, 2, 9, 7, 5, 3 };
	        List<Integer> longestIncreasingSubsequence = findLongestIncreasingSubsequence(numbers);

	        System.out.println("Longest Increasing Subsequence: " + longestIncreasingSubsequence);
	    }

	    public static List<Integer> findLongestIncreasingSubsequence(int[] numbers) {
	        int n = numbers.length;
	        int[] dp = new int[n]; 
	        Arrays.fill(dp, 1); // Initialize all elements with 1

	        // Find the longest increasing subsequence
	        for (int i = 1; i < n; i++) {
	            for (int j = 0; j < i; j++) {
	                if (numbers[i] > numbers[j] && dp[i] < dp[j] + 1) {
	                    dp[i] = dp[j] + 1;
	                }
	            }
	        }

	        // Find the maximum length of the increasing subsequence
	        int maxLength = 0;
	        for (int i = 0; i < n; i++) {
	            if (dp[i] > maxLength) {
	                maxLength = dp[i];
	            }
	        }

	        // Build the longest increasing subsequence
	        List<Integer> longestIncreasingSubsequence = new ArrayList<>();
	        int currentLength = maxLength;
	        for (int i = n - 1; i >= 0; i--) {
	            if (dp[i] == currentLength) {
	                longestIncreasingSubsequence.add(0, numbers[i]);
	                currentLength--;
	            }
	        }

	        return longestIncreasingSubsequence;
	    }
	}
