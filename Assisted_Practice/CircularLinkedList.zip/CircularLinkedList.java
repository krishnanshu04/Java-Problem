package practiceproject;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedListInsertion {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (data <= head.data) {
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        System.out.println("Circular Linked List:");
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class CircularLinkedList {
	    public static void main(String[] args) {
	        CircularLinkedListInsertion list = new CircularLinkedListInsertion();
	        list.insert(2);
	        list.insert(4);
	        list.insert(6);
	        list.insert(8);
	        list.insert(10);

	        list.display();
	    }
	}

