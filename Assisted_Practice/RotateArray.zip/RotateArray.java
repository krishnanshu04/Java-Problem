package practiceproject;

public class RotateArray {
	
	public static void main(String[] args) {
		
		int[] arr = {1,2,3,4,5,6,7,8,9,10};
		int step = 5;
		int len=arr.length;
		
		int[] temp = new int[len];
		
		System.out.println("Array before rotate");
		for(int i : arr) {
			System.out.print(i+" ");
		}
		
		for(int i=0; i<step; i++) {
			
			int start = i;
			int end = len-1-i;
			
			temp[start]=arr[end];
			temp[end]=arr[start];
		}
		
		for(int i=0; i<len; i++) {
			arr[i]=temp[i];
		}
		
		System.out.println();
		System.out.println("Array after rotate");
		for(int i : arr) {
			System.out.print(i+" ");
		}
	}

}
