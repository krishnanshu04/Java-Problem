package practiceproject;

public class Question8 {
	
	public static void main(String[] args) {
		
		String s1="String";
		
		//Convert the String to StringBuffer.
		StringBuffer sb1 = new StringBuffer(s1);
		System.out.println(sb1);
		
		//Convert the String to StringBuilder
		StringBuilder sb2 = new StringBuilder(s1);
		System.out.println(sb2);
		
		//Convert StringBuffer to String
		String s2=sb1.toString();
		
		//Convert StringBuilder to String
		String s3=sb2.toString();
		
		
	}

}
