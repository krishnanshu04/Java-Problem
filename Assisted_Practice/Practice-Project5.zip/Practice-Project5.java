package practiceproject;

import java.util.*;

public class Question5 {
	public static void main(String[] args) {
		
		ArrayList<String> name = new ArrayList<String>();
		
		//Inserting an elements
		name.add("Shubham");
		name.add("Anjali");
		name.add("Srijan");
		
		System.out.println(name);
		
		//Size of an ArrayList.
		System.out.println(name.size());
		
		//Add an element in specific index
		name.add(1,"Aditya");
		System.out.println(name);
		
		//Remove an element from ArrayList
		name.remove(0);
		System.out.println(name);
		
		//Updating an element in specific index
		name.set(2, "Krish");
		System.out.println(name);
	}
}
