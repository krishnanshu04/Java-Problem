package practiceproject;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a regular expression: ");
        String regex = scanner.nextLine();

        System.out.print("Enter a test string: ");
        String testString = scanner.nextLine();

        if (matches(regex, testString)) {
            System.out.println("Match found!");
        } else {
            System.out.println("No match found!");
        }

        scanner.close();
    }
	
	public static boolean matches(String regex, String testString) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(testString);
        return matcher.matches();
    }

}
