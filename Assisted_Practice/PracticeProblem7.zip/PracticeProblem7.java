package practiceproject;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.io.FileReader;

public class PracticeProblem7 {

	public static void main(String[] args) throws IOException {
		
		File newFile=new File("C:\\Users\\KIIT\\Documents\\Demo.txt");
		
		//Creating file inside local directory.
		if(newFile.createNewFile()) {
			System.out.println("File is created successfully");
		}else if(newFile.exists()) {
			System.out.println("File is already present");
		}else {
			System.out.println("File is not created yet");
		}
		
		//Writing in newFile
		
		FileWriter f = new FileWriter("C:\\Users\\KIIT\\Documents\\Demo.txt");
	
		f.write("I am working in the company");
		f.close();
		
		//Reading the newFile
		
		FileReader reader = new FileReader("C:\\Users\\KIIT\\Documents\\Demo.txt");
		
		int i;
		while((i=reader.read())!=-1) {
			System.out.print((char)i);
		}
		
		reader.close();
		
	
		if(newFile.delete()) {
			System.out.println("\n"+newFile.getName()+" file is deleted");
		}else {
			System.out.println("Failed");
		}
	}

}
