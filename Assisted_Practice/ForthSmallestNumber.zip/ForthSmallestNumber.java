package practiceproject;

import java.util.Arrays;

public class ForthSmallestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] unsortedList = {10,5,8,3,2,7,6,1};
		
		Arrays.sort(unsortedList);
		
		System.out.println("Forth smallest number in the unsortedList is "+unsortedList[3]);

	}

}
