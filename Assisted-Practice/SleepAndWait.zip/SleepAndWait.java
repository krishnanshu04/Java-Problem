package practiceproject;

import java.lang.Thread;

class SleepThread extends Thread{
	
	public void run(){
		
		System.out.println(Thread.currentThread().getName()+" before sleep");
		try {
		Thread.sleep(2000); //Sleep for 5 second
		}catch(Exception e) {
			System.out.println(e);
	
		}
		//This will print after 2 seconds
		System.out.println(Thread.currentThread().getName()+" after sleep");
	}
	
}

class WaitThread extends Thread{
	
	public void run() {
		
		synchronized(this) {
			try {
				
				System.out.println(Thread.currentThread().getName()+" is start");
				wait(2000); //Wait for 2 second
				System.out.println(Thread.currentThread().getName()+" after wait");
				
			}catch(Exception e) {
				System.out.println(e);
			}
		}
	}
}
public class SleepAndWait {
	
	public static void main(String[] args) {
		
		SleepThread sleep=new SleepThread();
		sleep.start();
		
		WaitThread wait=new WaitThread();
		wait.start();
		
	}
	
}
