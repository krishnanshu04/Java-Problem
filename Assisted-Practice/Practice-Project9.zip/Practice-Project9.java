package practiceproject;

import java.util.*;
public class Question9 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.print("Enter the size of array : ");
		int n=sc.nextInt();
		
		int[] arr=new int[n];
		
		for(int i=1; i<=n; i++) {
			System.out.print("Insert element at "+i+" : ");
			arr[i]=sc.nextInt();
		}
		for(int i=1; i<=n; i++) {
			System.out.println("Element at "+i+" : "+arr[i]);
			
		}
		
	}

}
