package practiceproject;

class AccessModifier{
	
	private int privateField; //can't be acccess from outside of class.
	int defaultField; //can be access within the package
	protected int protectedFiled; //can be access within the package and also outside the package with child class.
	public int publicFiled; // can be access from anywhere
	
	private void privateMethod() {
		System.out.println("This is the private method");
	}
	
	void defaultMethod() {
		System.out.println("This is the default method");
	}
	
	protected void protectedMethod() {
		System.out.println("This is the protected method");
	}
	
	public void publicMethod() {
		System.out.println("This is the public method");
	}
}

public class Q2 {
	
	public static void main(String[] args) {
		AccessModifier obj = new AccessModifier();
		obj.privateField=1; // error - cannot access private field
		obj.protectedFiled=2;
		obj.defaultField=3;
		obj.publicFiled=4;
		
		obj.privateMethod(); // error - cannot access private method
		obj.protectedMethod();
		obj.defaultMethod();
		obj.publicMethod();
	}
	
}
