package practiceproject;

//Abstract Class
abstract class AbstractClass {
	
	//Abstract method
	public abstract void show();
	
	public void display() {
		System.out.println("Inside abstarct class");
	}
}

//Inheritance
class SubClass extends AbstractClass{
	
	public void show() {
		System.out.println("Score of given test");
	}
	
	@Override //Runtime Polymorphism.
	public void display() {
		System.out.println("Inside score class");
	}
}

//Encapsulation
class Person{
	
	private String personName;
	private float personAge;
	
	public void setName(String personName) {
		this.personName=personName;
	}
	
	public String getName() {
		return personName;
	}
	
	public void setAge(int personAge) {
		this.personAge=personAge;
	}
	
	public int getAge() {
		return (int)personAge;
	}

}

//Inheritance
class Student extends Person{
	
	private int rollNumber;
	
	public void setRollNumber(int rollNumber) {
		this.rollNumber=rollNumber;
	}
	
	public int getRollNumber() {
		return rollNumber;
	}
}





public class PracticeProblem8 {

	public static void main(String[] args) {
		
		
		Student st1=new Student();
		
		AbstractClass obj=new SubClass();
		obj.display();
		
		//Setting the details of Student
		st1.setName("Rahul");
		st1.setAge(22);
		st1.setRollNumber(1806587);
		
		//Getting the details of Student
		System.out.println(st1.getName());
		System.out.println(st1.getAge());
		System.out.println(st1.getRollNumber());
		

	}

}
