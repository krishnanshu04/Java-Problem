package practiceproject;

public class Question3 {
	
	public static void main(String[] args) {
		
		fun1(); // Static method called without creating an object of class.
		
		Question3 obj= new Question3();
		
		obj.fun2(); // Non-static method called with the help of an object.
		
	}
	
	public static void fun1() {
		System.out.println("Static function");
	}
	
	public void fun2() {
		System.out.println("Non-static function");
	}

}
