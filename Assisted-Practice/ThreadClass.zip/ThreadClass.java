package practiceproject;

class Test extends Thread{
	
	public void run() {
		System.out.println("Implementing thread by extending thread class");
		System.out.println("Name of current thread is "+Thread.currentThread().getName());
	}
}

class Test1 implements Runnable{
	
	public void run() {
		
		System.out.println("Implementing thread by using runnable interface");
		System.out.println("Name of current thread is "+Thread.currentThread().getName());
	}
}

public class ThreadClass {
	
	public static void main(String[] args) {
		
		Test t1=new Test();
		t1.start();
		
		Test1 t2=new Test1();
		Thread th=new Thread(t2);
		th.start();
		
		
	}

}
