package practiceproject;

public class TryCatchBlock {
	
	public static void main(String[] args) {
		
		try {
			int i=10/0;
			String s=null;
			s.length();
			
			int[] arr= {1,2,3,4,5};
			System.out.println(arr[7]);
		}
		catch(ArithmeticException e) {
			System.out.println(e);
		}
		catch(NullPointerException e) {
			System.out.println(e);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

}
