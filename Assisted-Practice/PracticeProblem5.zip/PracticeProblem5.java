package practiceproject;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

class InvalidInputException extends Exception{
	
	
	public InvalidInputException(String message) {
		super(message);
	}
}

public class PracticeProblem5 {
	
	public static void main(String[] args) throws IOException, InvalidInputException {
		
		Scanner sc=new Scanner(System.in);
		
		File f=new File("C:\\Users\\KIIT\\Documents\\name.txt");
		
		boolean b = f.createNewFile();
		System.out.println(b);
		
		
		try {
			int i=10/0;
		}
		
		finally {
			
			System.out.println("This is finally block");
			
			//If below code were written outside the finally block then it will never execute because i don't handle the exception in try block followed by catch block
			System.out.println("Enter the age : ");
			
			int age = sc.nextInt();
			
			if(age<18) { //Custom exception
				
				 throw new InvalidInputException("Not eligible for vote");
				 
			}else {
				System.out.println("Eligible for vote");
			}
		}
			
	}

}
