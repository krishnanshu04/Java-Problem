package practiceproject;

class OuterClass{
	
	int num=20;
	
	public void fun1() {
		System.out.println("Method of outer class");
	}
	
	class InnerClass{
		
		public void fun2() {
			System.out.println("Method of inner class");
			System.out.println(num);
		}
	}
	
}

public class Question7 {
	
	public static void main(String[] args) {
		
		//Object of outer class
		OuterClass out=new OuterClass();
		out.fun1();
		
		//Object of inner class or nested class
		OuterClass.InnerClass inn=out.new InnerClass();
		inn.fun2();
	}
	

}
