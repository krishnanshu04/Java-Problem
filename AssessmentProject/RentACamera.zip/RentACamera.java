package com.camera;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class MyWallet{
	
	static Integer amount=0;
	
	
	public static void myWallet() {
		
	List<Object[]> data = new ArrayList<Object[]>();
	System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERA(S) - ");
		data.add(new Object[]{1,"Samsung","DS123",500,"Available"});
		data.add(new Object[]{2,"Sony","HD214",500,"Avaiable"});
		data.add(new Object[]{3,"Panasonic","XC",500,"Avaiable"});
		data.add(new Object[]{4,"Canon","XLR",500,"Avaiable"});
		data.add(new Object[]{5,"Fujitsu","J5",500,"Avaiable"});
		data.add(new Object[]{6,"Sony","HD226",500,"Avaiable"});
		data.add(new Object[]{8,"LG","L123",500,"Avaiable"});
		data.add(new Object[]{9,"canon","XPL",500,"Avaiable"});
		data.add(new Object[]{10,"Chroma","CT",500,"Avaiable"});
		data.add(new Object[]{13,"Canon","Digital",123,"Avaiable"});
		data.add(new Object[]{14,"NIKON","DSLR-D7500",500,"Avaiable"});
		data.add(new Object[]{15,"Sony","DSLR12",500,"Avaiable"});
		data.add(new Object[]{19,"SONY","SONY1234",123,"Avaiable"});
		data.add(new Object[]{20,"canon","5050",25000,"Avaiable"});
		data.add(new Object[]{21,"nikon","2030",500.0,"Avaiable"});
	
	Scanner sc=new Scanner(System.in);
		
		System.out.println("TRANSACTION FAILED DUE TO INSUFFICIENT WALLET BALANCE. PLEASE DEPOSITE AMOUNT TO YOUR WALLET");
		System.out.println("YOUR CURRENT WALLET BALANCE IS - INR."+amount);
		System.out.println("DO YOU WANT TO DEPOSITE MORE AMOUNT TO YOUR WALLET?(1. YES 2.NO) - ");
		int option = sc.nextInt();
		
		for(int i=1; i<=2; i++) {
			if(option==i) {
				System.out.print("ENTER THE AMOUNT (INR) - ");
				int add = sc.nextInt();
				amount=amount+add;
				System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE - INR."+amount);
				break;
			}else {
				System.out.println("OK");
			}
		}
		
		myWallet(data,20);
		
		
		System.out.println("=========================================================================");
			System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", "CAMERA Id","BRAND","MODEL","PRICE","STATUS");
			System.out.println("=========================================================================");
			
			for(Object[] row : data) {
				System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", row[0],row[1],row[2],row[3],row[4]);
			}

			System.out.println("=========================================================================");
		
		
		
	}
	
	public static void myWallet(List<Object[]> data, Integer id){
			
		   Iterator<Object[]> iterator = data.iterator();
		  
		   while (iterator.hasNext()) {
	            Object[] row = iterator.next();
	            if (row[0].equals(id)) {
	                if(row[3].equals(amount)) {
	                	row[4]="Rented";
	                }else {
	                	myWallet();
	                }
	            }
	        }
		}
	
}

public class RentACamera {
	
 			public static void rentCamera()throws Exception{
 				
 				Scanner sc=new Scanner(System.in);
 				List<Object[]> data = new ArrayList<Object[]>();
 				
 				String cameraId="CAMERA ID";
 				String brand="BRAND";
 				String model="MODEL";
 				String price="PRICE(PER DAY)";
 				String status="STATUS";
 				
 				System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERA(S) - ");
 				data.add(new Object[]{1,"Samsung","DS123",500,"Available"});
 				data.add(new Object[]{2,"Sony","HD214",500,"Avaiable"});
 				data.add(new Object[]{3,"Panasonic","XC",500,"Avaiable"});
 				data.add(new Object[]{4,"Canon","XLR",500,"Avaiable"});
 				data.add(new Object[]{5,"Fujitsu","J5",500,"Avaiable"});
 				data.add(new Object[]{6,"Sony","HD226",500,"Avaiable"});
 				data.add(new Object[]{8,"LG","L123",500,"Avaiable"});
 				data.add(new Object[]{9,"canon","XPL",500,"Avaiable"});
 				data.add(new Object[]{10,"Chroma","CT",500,"Avaiable"});
 				data.add(new Object[]{13,"Canon","Digital",123,"Avaiable"});
 				data.add(new Object[]{14,"NIKON","DSLR-D7500",500,"Avaiable"});
 				data.add(new Object[]{15,"Sony","DSLR12",500,"Avaiable"});
 				data.add(new Object[]{19,"SONY","SONY1234",123,"Avaiable"});
 				data.add(new Object[]{20,"canon","5050",25000,"Avaiable"});
 				data.add(new Object[]{21,"nikon","2030",500.0,"Avaiable"});
 				
 				
 				System.out.println("=========================================================================");
 				System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", cameraId,brand,model,price,status);
 				System.out.println("=========================================================================");
 				
 				for(Object[] row : data) {
 					System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", row[0],row[1],row[2],row[3],row[4]);
 				}

 				System.out.println("=========================================================================");
 				
 				System.out.println("ENTER THE CAMERA ID YOU WANT TO RENT - ");
 				Integer id=sc.nextInt();
 				MyWallet.myWallet(data,id);
 				
 		
 			}
 			
 	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
	
	}

}
