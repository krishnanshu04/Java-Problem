package com.camera;

import java.util.*;

public class LoginPage {
	
	
	public static void main(String[] args) throws Exception{
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("+-----------------------------------------+");
		System.out.println("\tWELCOME TO CAMERA RENTAL APP");
		System.out.println("+-----------------------------------------+");
		System.out.println("PLEASE LOGIN TO CONTINUE");
		System.out.println();
		
		System.out.print("USERNAME - ");
		Set username=new HashSet<String>();
		username.add(sc.nextLine());
		
		System.out.print("PASSWORD - ");
		Set userpass=new HashSet<String>();
		userpass.add(sc.nextLine());
		
		viewMainMenu();

		
		
	
	}
		
	
	public static void viewMainMenu() throws Exception {
		
		Scanner sc=new Scanner(System.in);
		String[] menu = {"1. MY CAMERA","2. RENT A CAMERA", "3. VIEW ALL CAMERAS","4. MY WALLET","5. EXIT"};
		
		int[] arr = {1,2,3,4,5};
		int size=arr.length;
		
		for(int i=0; i<size; i++) {
			
			System.out.println(menu[i]);
		}
		
		System.out.print("Choose the option from above menu - ");
		int menuOption = sc.nextInt();
		
		for(int i=1; i<6; i++) {
			if(menuOption==i) {
				switch(menuOption) {
				case 1:
					MyCamera.myCamera();
					break;
					
				case 2:
					RentACamera.rentCamera();
					break;
				case 3:
					ViewAllCamera.viewAllCamera();
					
				case 4:
					MyWallet.myWallet();
					break;
					
				case 5:
					Exit.exit();
					break;
					
				default:
					System.out.println("Enter the correct option");
				}
			}
		}

	}
	
}
