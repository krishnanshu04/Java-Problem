package com.camera;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ViewAllCamera {
	
	public static void viewAllCamera() {
		Scanner sc=new Scanner(System.in);
			List<Object[]> data = new ArrayList<Object[]>();
			
			String cameraId="CAMERA ID";
			String brand="BRAND";
			String model="MODEL";
			String price="PRICE(PER DAY)";
			String status="STATUS";
			
			System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERA(S) - ");
			data.add(new Object[]{1,"Samsung","DS123",500,"Available"});
			data.add(new Object[]{2,"Sony","HD214",500,"Avaiable"});
			data.add(new Object[]{3,"Panasonic","XC",500,"Avaiable"});
			data.add(new Object[]{4,"Canon","XLR",500,"Avaiable"});
			data.add(new Object[]{5,"Fujitsu","J5",500,"Avaiable"});
			data.add(new Object[]{6,"Sony","HD226",500,"Avaiable"});
			data.add(new Object[]{8,"LG","L123",500,"Avaiable"});
			data.add(new Object[]{9,"canon","XPL",500,"Avaiable"});
			data.add(new Object[]{10,"Chroma","CT",500,"Avaiable"});
			data.add(new Object[]{13,"Canon","Digital",123,"Avaiable"});
			data.add(new Object[]{14,"NIKON","DSLR-D7500",500,"Avaiable"});
			data.add(new Object[]{15,"Sony","DSLR12",500,"Avaiable"});
			data.add(new Object[]{19,"SONY","SONY1234",123,"Avaiable"});
			data.add(new Object[]{20,"canon","5050",25000,"Rented"});
			data.add(new Object[]{21,"nikon","2030",500.0,"Avaiable"});
			
			
			System.out.println("=========================================================================");
			System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", cameraId,brand,model,price,status);
			System.out.println("=========================================================================");
			
			for(Object[] row : data) {
				System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", row[0],row[1],row[2],row[3],row[4]);
			}

			System.out.println("=========================================================================");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
