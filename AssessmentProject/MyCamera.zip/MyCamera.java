package com.camera;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class MyCamera {
 		
	public static void myCamera() throws Exception{
		
		Scanner sc=new Scanner(System.in);
		String[] cameraMenu= {"1. ADD", "2. REMOVE", "3. VIEW MY CAMERA","4. GO TO PREVIOUS MENU"};
		
		
		int[] arr = {1,2,3,4};
		int size=arr.length;
		
		for(int i=0; i<size; i++) {
			
			System.out.println(cameraMenu[i]);
		}
		
		
		System.out.print("Choose from above option - ");
		int option = sc.nextInt();
		
		for(int i=1; i<=arr.length; i++) {
			if(option==i) {
				switch(option) {
				case 1:
					add();
					break;
				
				case 2:
					remove();
					break;
				case 3:
					view();
					break;
				
				case 4:
					LoginPage.viewMainMenu();
					break;
					
				default:
					System.out.println("Enter the wrong option");
			  }
		   }		
	    }
	}

		
	public static void add(){
		
		Scanner sc=new Scanner(System.in);
		
		List<String> details = new ArrayList<>();
		List<Integer> price = new ArrayList<>();
		System.out.print("ENTER THE CAMERA BRAND - ");
		details.add(sc.nextLine());
		System.out.println();
		System.out.print("ENTER THE MODEL NAME - ");
		details.add(sc.nextLine());
		System.out.println();
		System.out.print("ENTER THE PER DAY PRICE(INR) - ");
		price.add(sc.nextInt());
		System.out.println();
		System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
	}
	
	public static void remove() {

		Scanner sc=new Scanner(System.in);
		List<String[]> data = new ArrayList<String[]>();
		
		data.add(new String[]{"11","Something","some","200.0","Rented"});
		data.add(new String[]{"12","some","Another","100.0","Avaiable"});
		data.add(new String[]{"14","NIKON","DSLR-D7500","500.0","Avaiable"});
		data.add(new String[]{"15","Sony","DSLR12","200.0","Avaiable"});
		data.add(new String[]{"17","Samsung","SM123","200.0","Avaiable"});
		data.add(new String[]{"19","SONY","SONY1234","123.0","Avaiable"});
		data.add(new String[]{"20","canon","5050","25000.0","Avaiable"});
		data.add(new String[]{"21","nikon","2030","500.0","Avaiable"});
		
		
		System.out.println("=========================================================================");
		System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", "CAMERA ID","BRAND","MODEL","PRICE(PER DAY)","STATUS");
		System.out.println("=========================================================================");
		
		for(String[] row : data) {
			System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", row[0],row[1],row[2],row[3],row[4]);
		}

		System.out.println("=========================================================================");
		
		System.out.println("ENTER THE CAMERA ID TO REMOVE - ");
		
		String rowIndex = sc.nextLine();
		
		deleteRow(data, rowIndex);
		
		
		
	}
	
	
	public static void deleteRow(List<String[]> data, String rowIndex) {
		
	    Iterator<String[]> iterator = data.iterator();

        while (iterator.hasNext()) {
            String[] row = iterator.next();
            if (row[0].equals(rowIndex)) {
                iterator.remove(); 
                System.out.println("CAMERA SUCCESSFULLY REMOVE FROM LIST");
            }
        }
        
		System.out.println("=========================================================================");
		System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", "CAMERA ID","BRAND","MODEL","PRICE(PER DAY)","STATUS");
		System.out.println("=========================================================================");
		
		for(String[] row : data) {
			System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", row[0],row[1],row[2],row[3],row[4]);
		}

		System.out.println("=========================================================================");
        
	}
	
	public static void view() {
		
		Scanner sc=new Scanner(System.in);
		List<String[]> data = new ArrayList<String[]>();
		
		data.add(new String[]{"11","Something","some","200.0","Rented"});
		data.add(new String[]{"12","some","Another","100.0","Avaiable"});
		data.add(new String[]{"14","NIKON","DSLR-D7500","500.0","Avaiable"});
		data.add(new String[]{"15","Sony","DSLR12","200.0","Avaiable"});
		data.add(new String[]{"17","Samsung","SM123","200.0","Avaiable"});
		data.add(new String[]{"19","SONY","SONY1234","123.0","Avaiable"});
		data.add(new String[]{"20","canon","5050","25000.0","Avaiable"});
		data.add(new String[]{"21","nikon","2030","500.0","Avaiable"});
		
		
		System.out.println("=========================================================================");
		System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", "CAMERA ID","BRAND","MODEL","PRICE(PER DAY)","STATUS");
		System.out.println("=========================================================================");
		
		for(String[] row : data) {
			System.out.printf("%-15s %-15s %-15s %-15s %-15s%n", row[0],row[1],row[2],row[3],row[4]);
		}

		System.out.println("=========================================================================");
		
	}
	
 


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
